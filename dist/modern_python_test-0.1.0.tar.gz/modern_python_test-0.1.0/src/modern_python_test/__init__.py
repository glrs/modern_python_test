# src/modern_python_test/__init__.py
"""The modern Python test project."""
__version__ = "0.1.0"
